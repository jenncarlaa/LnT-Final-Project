package ptpudding;

import javax.swing.*;
import java.awt.*;

public class MainApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Aplikasi Database PT Pudding");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);

        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 10));

        JButton insertButton = new JButton("Insert Menu");
        JButton viewButton = new JButton("View Menu");
        JButton updateButton = new JButton("Update Menu");
        JButton deleteButton = new JButton("Delete Menu");

        buttonPanel.add(insertButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        frame.add(mainPanel);

        DatabaseHelper.createTable();

        insertButton.addActionListener(e -> InsertMenuForm.showForm(frame));
        viewButton.addActionListener(e -> DatabaseHelper.viewMenu(outputArea));
        updateButton.addActionListener(e -> UpdateMenuForm.showForm(frame));
        deleteButton.addActionListener(e -> DeleteMenuForm.showForm(frame));

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}