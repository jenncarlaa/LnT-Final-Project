package ptpudding;

import java.sql.*;
import java.util.Random;
import javax.swing.JTextArea;

public class DatabaseHelper {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/pt_pudding";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    public static void createTable() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            String sql = "CREATE TABLE IF NOT EXISTS menu (" +
                         "kode_menu VARCHAR(10) PRIMARY KEY," +
                         "nama_menu VARCHAR(50) NOT NULL," +
                         "harga_menu INT NOT NULL," +
                         "stok_menu INT NOT NULL)";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static String generateKodeMenu() {
        Random rand = new Random();
        return "PD-" + (rand.nextInt(900) + 100);
    }

    public static void insertMenu(String kode, String nama, int harga, int stok) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                     "INSERT INTO menu (kode_menu, nama_menu, harga_menu, stok_menu) VALUES (?, ?, ?, ?)")) {
            pstmt.setString(1, kode);
            pstmt.setString(2, nama);
            pstmt.setInt(3, harga);
            pstmt.setInt(4, stok);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewMenu(JTextArea outputArea) {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM menu")) {

            outputArea.setText(String.format("%-10s %-20s %-10s %-10s\n", "Kode", "Nama Menu", "Harga", "Stok"));
            outputArea.append("------------------------------------------------------\n");

            while (rs.next()) {
                outputArea.append(String.format("%-10s %-20s %-10d %-10d\n",
                        rs.getString("kode_menu"),
                        rs.getString("nama_menu"),
                        rs.getInt("harga_menu"),
                        rs.getInt("stok_menu")));
            }
        } catch (SQLException e) {
            outputArea.setText("Error: " + e.getMessage());
        }
    }

    public static void updateMenu(String kode, int hargaBaru, int stokBaru) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                     "UPDATE menu SET harga_menu = ?, stok_menu = ? WHERE kode_menu = ?")) {
            pstmt.setInt(1, hargaBaru);
            pstmt.setInt(2, stokBaru);
            pstmt.setString(3, kode);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteMenu(String kode) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                     "DELETE FROM menu WHERE kode_menu = ?")) {
            pstmt.setString(1, kode);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}